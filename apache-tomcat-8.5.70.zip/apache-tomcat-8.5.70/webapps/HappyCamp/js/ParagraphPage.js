function ReturnToParagraphList(){
    window.location.href="ParagraphList";
}