function gotoSignupPage() {
    window.location.href="Signup";
}